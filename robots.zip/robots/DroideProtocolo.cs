
public class DroideProtocolo : Robots {
    public DroideProtocolo(string name, int tipoUnidad, int bateria) : base(name, tipoUnidad, bateria) {}

}